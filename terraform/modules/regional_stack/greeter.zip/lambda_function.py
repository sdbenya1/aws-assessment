import json, os, time
import boto3

ddb = boto3.client("dynamodb")
sns = boto3.client("sns", region_name=os.environ.get("SNS_REGION", "us-east-1"))

TABLE = os.environ["TABLE_NAME"]
SNS_ARN = os.environ["SNS_ARN"]
EMAIL = os.environ["EMAIL"]
REPO_URL = os.environ["REPO_URL"]
REGION = os.environ["AWS_REGION"]

def handler(event, context):
    # Write a simple record
    pk = str(int(time.time() * 1000))
    ddb.put_item(
        TableName=TABLE,
        Item={
            "pk": {"S": pk},
            "email": {"S": EMAIL},
            "region": {"S": REGION}
        }
    )

    # Publish verification payload
    payload = {
        "email": EMAIL,
        "source": "Lambda",
        "region": REGION,
        "repo": REPO_URL
    }
    sns.publish(TopicArn=SNS_ARN, Message=json.dumps(payload))

    return {
        "statusCode": 200,
        "headers": {"content-type": "application/json"},
        "body": json.dumps({"region": REGION})
    }
